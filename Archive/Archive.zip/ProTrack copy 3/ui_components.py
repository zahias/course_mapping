import streamlit as st
import pandas as pd
from config import get_default_target_courses, get_intensive_courses

def display_sidebar(default_grading_system):
    st.sidebar.subheader("Customize Target and Intensive Courses")
    st.sidebar.markdown(
        "Upload a CSV with columns: `Course`, `Credits`, and optional `Type` (`Required` or `Intensive`)."
    )

    if st.sidebar.button("Download Template", help="Download a CSV template to define required and intensive courses."):
        template_df = pd.DataFrame({
            'Course': ['ENGL201', 'CHEM201', 'INEG200', 'MATH101'],
            'Credits': [3, 3, 3, 3],
            'Type': ['Required', 'Required', 'Intensive', 'Required']
        })
        csv_data = template_df.to_csv(index=False).encode('utf-8')
        st.sidebar.download_button(
            label="Download CSV Template",
            data=csv_data,
            file_name='course_template.csv',
            mime='text/csv'
        )

    uploaded_courses = st.sidebar.file_uploader("Upload Custom Courses (CSV)", type="csv", key='courses',
                                                help="Include 'Type' column to differentiate between Required and Intensive.")

    if uploaded_courses is not None:
        custom_df = pd.read_csv(uploaded_courses)
        if 'Course' in custom_df.columns and 'Credits' in custom_df.columns:
            if 'Type' in custom_df.columns:
                required_df = custom_df[custom_df['Type'].str.lower() == 'required']
                intensive_df = custom_df[custom_df['Type'].str.lower() == 'intensive']

                target_courses = dict(zip(required_df['Course'].str.upper(), required_df['Credits']))
                intensive_courses = dict(zip(intensive_df['Course'].str.upper(), intensive_df['Credits']))
                st.sidebar.success("Custom required and intensive courses loaded.")
            else:
                target_courses = dict(zip(custom_df['Course'].str.upper(), custom_df['Credits']))
                intensive_courses = get_intensive_courses()
                st.sidebar.info("No 'Type' column found. Using default intensive courses with your custom required courses.")
        else:
            st.sidebar.error("CSV must contain 'Course' and 'Credits' columns.")
            target_courses = get_default_target_courses()
            intensive_courses = get_intensive_courses()
    else:
        target_courses = get_default_target_courses()
        intensive_courses = get_intensive_courses()

    st.sidebar.subheader("Customize Grading System")
    st.sidebar.markdown("Select which grades count towards completion.")

    all_possible_grades = default_grading_system['Counted'] + default_grading_system['Not Counted']
    counted_grades = st.sidebar.multiselect(
        "Select Counted Grades",
        options=all_possible_grades,
        default=default_grading_system['Counted'],
        key='grades',
        help="These grades count as completed."
    )
    not_counted_grades = [grade for grade in all_possible_grades if grade not in counted_grades]
    grading_system = {'Counted': counted_grades, 'Not Counted': not_counted_grades}

    st.sidebar.write("**Current Grading System:**")
    st.sidebar.write(f"**Counted Grades:** {', '.join(grading_system['Counted'])}")
    st.sidebar.write(f"**Not Counted Grades:** {', '.join(grading_system['Not Counted'])}")

    st.sidebar.subheader("View Options")
    grade_toggle = st.sidebar.checkbox(
        "Show All Grades",
        value=False,
        key='grade_toggle',
        help="Display all attempts/grades per course."
    )
    completed_toggle = st.sidebar.checkbox(
        "Show Completed/Not Completed Only",
        value=False,
        key='completed_toggle',
        help="Displays 'c' for completed and '' for incomplete courses."
    )

    return target_courses, intensive_courses, grading_system, grade_toggle, completed_toggle

def display_main_interface():
    st.markdown("""
    **Instructions:**
    - Use the sidebar to customize courses and grading system.
    - Upload a progress report file.
    - Assign S.C.E. and F.E.C. for extra courses.
    - Download the processed report.
    
    **Color Legend:**
    - Light Green: Completed/Counted
    - Light Yellow: Currently Registered (CR)
    - Pink: Not Completed/Not Counted
    """)

def add_sce_fec_selection(extra_courses_df):
    extra_courses_df['ID'] = extra_courses_df['ID'].astype(str)
    extra_courses_df['NAME'] = extra_courses_df['NAME'].astype(str)
    extra_courses_df['Course'] = extra_courses_df['Course'].astype(str)
    extra_courses_df['Grade'] = extra_courses_df['Grade'].astype(str)

    assignment_columns = ['ID', 'NAME', 'Course', 'Grade', 'S.C.E.', 'F.E.C.']
    extra_courses_assignment_df = extra_courses_df[assignment_columns]

    st.write("Check the boxes for S.C.E. or F.E.C. assignments:")
    edited_df = st.data_editor(
        extra_courses_assignment_df,
        num_rows="dynamic",
        use_container_width=True,
        key='extra_courses_editor'
    )
    return edited_df

def display_dataframes(styled_df, intensive_styled_df, extra_courses_df, df):
    tab1, tab2, tab3 = st.tabs(["Required Courses", "Intensive Courses", "Extra Courses"])
    with tab1:
        st.subheader("Required Courses Progress Report")
        st.dataframe(styled_df)
        st.markdown("*S.C.E./F.E.C. assigned courses appear here once selected.*")

    with tab2:
        st.subheader("Intensive Courses Progress Report")
        st.dataframe(intensive_styled_df)
        st.markdown("*Intensive courses displayed separately.*")

    with tab3:
        st.subheader("Extra Courses Detailed View")
        st.dataframe(extra_courses_df)
        st.markdown("*Assign S.C.E. or F.E.C. to these courses as needed.*")
